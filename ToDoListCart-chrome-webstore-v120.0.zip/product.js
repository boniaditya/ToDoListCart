(function () {
  const Store = globalThis.ToDoCartStore;
  const MAX_COMMENT_IMAGE_BYTES = 5 * 1024 * 1024;
  const state = {
    data: Store.normalizeData({}),
    productId: new URLSearchParams(window.location.search).get("id"),
    detailImageIndex: 0,
    dialogImages: [],
    dialogImageIndex: 0,
    activeResourceTab: new URLSearchParams(window.location.search).get("tab") || "description",
    commentImages: []
  };

  const elements = {
    brandName: document.querySelector(".brand-name"),
    productDetail: document.querySelector("#product-detail"),
    missingProduct: document.querySelector("#missing-product"),
    missingProductsLink: document.querySelector("#missing-products-link"),
    departments: document.querySelector(".departments"),
    detailImage: document.querySelector("#detail-image"),
    title: document.querySelector("#detail-title"),
    stars: document.querySelector("#detail-stars"),
    rating: document.querySelector(".detail-rating"),
    priority: document.querySelector("#detail-priority"),
    department: document.querySelector("#detail-department"),
    productType: document.querySelector("#detail-product-type"),
    location: document.querySelector("#detail-location"),
    moq: document.querySelector("#detail-moq"),
    stockUnits: document.querySelector("#detail-stock-units"),
    unitPrice: document.querySelector("#detail-unit-price"),
    price: document.querySelector("#detail-price"),
    created: document.querySelector("#detail-created"),
    description: document.querySelector("#detail-description"),
    references: document.querySelector("#detail-references"),
    referenceForm: document.querySelector("#detail-reference-form"),
    referenceInput: document.querySelector("#detail-reference-url"),
    referenceStatus: document.querySelector("#detail-reference-status"),
    referenceList: document.querySelector("#detail-reference-list"),
    emptyReferences: document.querySelector("#empty-reference-links"),
    relatedProducts: document.querySelector("#detail-related-products"),
    bundleProducts: document.querySelector("#detail-bundle-products"),
    vendorsPanel: document.querySelector("#detail-vendors"),
    descriptionPanel: document.querySelector("#detail-description-panel"),
    commentsPanel: document.querySelector("#product-comments"),
    resourceTabs: document.querySelector("#detail-resource-tabs"),
    resourceTabButtons: document.querySelectorAll("[data-resource-tab]"),
    commentForm: document.querySelector("#comment-form"),
    commentTitle: document.querySelector("#comment-title"),
    commentText: document.querySelector("#comment-text"),
    commentImageInput: document.querySelector("#comment-image-file"),
    commentImagePreview: document.querySelector("#comment-image-preview"),
    commentList: document.querySelector("#comment-list"),
    commentCount: document.querySelector("#comment-count"),
    emptyComments: document.querySelector("#empty-comments"),
    commentImageDialog: document.querySelector("#comment-image-dialog"),
    commentImageDialogTitle: document.querySelector("#comment-image-dialog-title"),
    commentImageDialogImage: document.querySelector("#comment-image-dialog-image"),
    closeCommentImageDialog: document.querySelector("#close-comment-image-dialog"),
    imageDialogReelPrevious: document.querySelector("#image-dialog-reel-previous"),
    imageDialogReelNext: document.querySelector("#image-dialog-reel-next"),
    imageDialogReelTrack: document.querySelector("#image-dialog-reel-track"),
    commentPanelToggle: document.querySelector("#toggle-comment-panel"),
    commentComposerPanel: document.querySelector("#comment-composer-panel"),
    commentsHeading: document.querySelector(".comments-heading"),
    cartSelect: document.querySelector("#cart-select"),
    cartCount: document.querySelector("#cart-count"),
    cartStatus: document.querySelector("#detail-cart-status"),
    stockStatus: document.querySelector("#detail-stock-status"),
    editProduct: document.querySelector("#detail-edit"),
    duplicateProduct: document.querySelector("#detail-duplicate"),
    addCart: document.querySelector("#detail-add-cart"),
    buyNow: document.querySelector("#detail-buy-now"),
    removeCart: document.querySelector("#detail-remove-cart"),
    done: document.querySelector("#detail-done"),
    deleteProduct: document.querySelector("#detail-delete"),
    openProductsPage: document.querySelector("#open-products-page"),
    openHomePage: document.querySelector("#open-home-page"),
    openOrdersPage: document.querySelector("#open-orders-page"),
    openAccountPage: document.querySelector("#open-account-page")
  };

  function getProduct() {
    return state.data.products.find((product) => product.id === state.productId);
  }

  function vendorTypeLabel(type) {
    return { person: "Individual", organization: "Organization", business: "Business" }[type] || "Business";
  }

  function renderCategoryNav(product) {
    elements.departments.replaceChildren();

    const addCategoryButton = (categoryId, label) => {
      const button = document.createElement("button");
      const active = categoryId === product?.department;

      button.type = "button";
      button.dataset.department = categoryId;
      if (categoryId === "all") {
        button.textContent = label;
      } else {
        Store.renderCategory(button, state.data, categoryId);
      }
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
      elements.departments.append(button);
    };

    addCategoryButton("all", "All");
    state.data.categories.forEach((category) => addCategoryButton(category.id, category.name));
  }

  function openCategory(categoryId) {
    const categoryQuery = categoryId === "all"
      ? ""
      : `?department=${encodeURIComponent(categoryId)}`;
    window.location.href = Store.getExtensionUrl(`newtab.html${categoryQuery}`);
  }

  function applyCommentPanelPlacement() {
    const inSidePanel = state.data.settings.commentComposerPlacement === "side";
    elements.productDetail.classList.toggle("comments-in-side-panel", inSidePanel);
    elements.productDetail.classList.remove("comments-expanded");
    if (inSidePanel) {
      elements.commentComposerPanel.hidden = false;
      elements.commentComposerPanel.append(elements.commentForm);
    } else {
      elements.commentComposerPanel.hidden = true;
      elements.commentsHeading.insertAdjacentElement("afterend", elements.commentForm);
    }
    elements.commentPanelToggle.setAttribute("aria-pressed", String(inSidePanel));
    const panelLabel = inSidePanel
      ? "Move add comment below details"
      : "Move add comment to side panel";
    elements.commentPanelToggle.setAttribute("aria-label", panelLabel);
    elements.commentPanelToggle.title = panelLabel;
  }

  async function toggleCommentPanelPlacement() {
    const willUseSidePanel = !elements.productDetail.classList.contains("comments-in-side-panel");
    state.data.settings.commentComposerPlacement = willUseSidePanel ? "side" : "below";
    state.data = await Store.saveData(state.data);
    applyCommentPanelPlacement();
  }

  function getActiveCart() {
    return Store.getActiveCart(state.data);
  }

  function getActiveItem() {
    return getActiveCart().items.find((item) => item.productId === state.productId);
  }

  function setActiveCart(nextCart) {
    state.data.carts = state.data.carts.map((cart) => (
      cart.id === nextCart.id ? nextCart : cart
    ));
  }

  function renderProductImage(product) {
    elements.detailImage.replaceChildren();
    elements.detailImage.classList.remove("has-carousel");
    elements.detailImage.removeAttribute("tabindex");
    elements.detailImage.removeAttribute("aria-label");
    elements.detailImage.onkeydown = null;
    const images = product.images || [];

    if (images.length && state.data.settings.showImages) {
      const track = document.createElement("div");
      track.className = "detail-carousel-track";

      images.forEach((entry, index) => {
        const imageButton = document.createElement("button");
        const image = document.createElement("img");

        imageButton.type = "button";
        imageButton.className = "detail-image-button";
        imageButton.setAttribute("aria-label", `Open full-size ${product.title} image ${index + 1} of ${images.length}`);
        image.src = entry.src;
        image.alt = `${product.title} product image ${index + 1} of ${images.length}`;
        imageButton.addEventListener("click", () => openImageDialog(
          entry,
          image.alt,
          `${product.title} image ${index + 1} of ${images.length}`,
          images,
          index,
          product.title
        ));
        imageButton.append(image);
        track.append(imageButton);
      });

      elements.detailImage.append(track);

      if (images.length > 1) {
        const previous = document.createElement("button");
        const next = document.createElement("button");
        const dots = document.createElement("div");

        elements.detailImage.classList.add("has-carousel");
        elements.detailImage.tabIndex = 0;
        elements.detailImage.setAttribute("aria-label", `${product.title} image gallery`);
        previous.type = "button";
        previous.className = "detail-carousel-button previous";
        previous.setAttribute("aria-label", "Previous image");
        previous.textContent = "‹";
        next.type = "button";
        next.className = "detail-carousel-button next";
        next.setAttribute("aria-label", "Next image");
        next.textContent = "›";
        dots.className = "detail-carousel-dots";

        images.forEach((entry, index) => {
          const dot = document.createElement("button");
          dot.type = "button";
          dot.className = "detail-carousel-dot";
          dot.setAttribute("aria-label", `Show image ${index + 1}`);
          dot.addEventListener("click", () => showDetailImage(index));
          dots.append(dot);
        });

        previous.addEventListener("click", () => showDetailImage(state.detailImageIndex - 1));
        next.addEventListener("click", () => showDetailImage(state.detailImageIndex + 1));
        elements.detailImage.onkeydown = (event) => {
          if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
            event.preventDefault();
            showDetailImage(state.detailImageIndex + (event.key === "ArrowLeft" ? -1 : 1));
          }
        };
        elements.detailImage.append(previous, next, dots);
      }

      state.detailImageIndex = Math.min(state.detailImageIndex, images.length - 1);
      showDetailImage(state.detailImageIndex);
      return;
    }

    elements.detailImage.append(document.createElement("span"));
  }

  function showDetailImage(index) {
    const product = getProduct();
    const images = product?.images || [];
    const track = elements.detailImage.querySelector(".detail-carousel-track");

    if (!track || !images.length) {
      return;
    }

    state.detailImageIndex = (index + images.length) % images.length;
    track.style.transform = `translateX(-${state.detailImageIndex * 100}%)`;
    [...track.children].forEach((image, imageIndex) => {
      image.setAttribute("aria-hidden", String(imageIndex !== state.detailImageIndex));
    });
    elements.detailImage.querySelectorAll(".detail-carousel-dot").forEach((dot, dotIndex) => {
      const active = dotIndex === state.detailImageIndex;
      dot.classList.toggle("active", active);
      dot.setAttribute("aria-current", active ? "true" : "false");
    });
  }

  function renderCartSelector() {
    elements.cartSelect.replaceChildren();

    state.data.carts.forEach((cart) => {
      const option = document.createElement("option");
      option.value = cart.id;
      option.textContent = cart.name;
      elements.cartSelect.append(option);
    });

    elements.cartSelect.value = state.data.activeCartId;
  }

  function renderComments(product) {
    const comments = [...(product.comments || [])].sort((first, second) => second.createdAt - first.createdAt);
    elements.commentList.replaceChildren();

    comments.forEach((comment) => {
      const item = document.createElement("li");
      const meta = document.createElement("div");
      const timestamp = document.createElement("time");
      const title = document.createElement("strong");
      const text = document.createElement("p");
      const remove = document.createElement("button");

      timestamp.dateTime = new Date(comment.createdAt).toISOString();
      timestamp.textContent = Store.formatDateTime(comment.createdAt);
      title.textContent = comment.title;
      text.textContent = comment.text;
      meta.className = "comment-meta";
      remove.type = "button";
      remove.className = "delete-comment-button";
      remove.setAttribute("aria-label", `Delete comment${comment.title ? `: ${comment.title}` : ""}`);
      remove.title = "Delete comment";
      remove.innerHTML = `
        <svg class="comment-delete-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
          <path d="M3 6h18"></path>
          <path d="M8 6V4h8v2"></path>
          <path d="M19 6l-1 14H6L5 6"></path>
          <path d="M10 11v5M14 11v5"></path>
        </svg>
      `;
      remove.addEventListener("click", () => deleteComment(comment.id));
      meta.append(timestamp, remove);
      item.append(meta);
      if (comment.title) {
        item.append(title);
      }
      if (comment.text) {
        item.append(text);
      }
      if (comment.images.length) {
        const images = document.createElement("div");
        images.className = "comment-images";
        comment.images.forEach((entry, index) => {
          const imageButton = document.createElement("button");
          const image = document.createElement("img");
          imageButton.type = "button";
          imageButton.className = "comment-image-button";
          imageButton.setAttribute("aria-label", `Open ${comment.title || `comment image ${index + 1}`}`);
          image.src = entry.src;
          image.alt = comment.title || `Comment image ${index + 1}`;
          imageButton.addEventListener("click", () => openCommentImage(comment.images, index, image.alt));
          imageButton.append(image);
          images.append(imageButton);
        });
        item.append(images);
      }
      elements.commentList.append(item);
    });

    elements.commentCount.textContent = `${comments.length} ${comments.length === 1 ? "comment" : "comments"}`;
    elements.emptyComments.hidden = comments.length > 0;
  }

  function showDialogImage(index) {
    if (!state.dialogImages.length) return;
    state.dialogImageIndex = (index + state.dialogImages.length) % state.dialogImages.length;
    const entry = state.dialogImages[state.dialogImageIndex];
    elements.commentImageDialogTitle.textContent = entry.dialogTitle;
    elements.commentImageDialogImage.src = entry.src;
    elements.commentImageDialogImage.alt = entry.dialogAlt;
    elements.imageDialogReelTrack.querySelectorAll("button").forEach((button, buttonIndex) => {
      const active = buttonIndex === state.dialogImageIndex;
      button.classList.toggle("active", active);
      button.setAttribute("aria-current", active ? "true" : "false");
    });
  }

  function renderImageDialogReel() {
    const reel = elements.imageDialogReelTrack.parentElement;
    elements.imageDialogReelTrack.replaceChildren();
    reel.hidden = state.dialogImages.length <= 1;
    state.dialogImages.forEach((entry, index) => {
      const button = document.createElement("button");
      const image = document.createElement("img");
      button.type = "button";
      button.className = "image-dialog-reel-stamp";
      button.setAttribute("aria-label", `Show image ${index + 1} of ${state.dialogImages.length}`);
      image.src = entry.src;
      image.alt = "";
      button.append(image);
      button.addEventListener("click", () => showDialogImage(index));
      elements.imageDialogReelTrack.append(button);
    });
  }

  function openImageDialog(entry, alt, title = "Image preview", gallery = [entry], index = 0, baseTitle = title) {
    state.dialogImages = gallery.map((image, imageIndex) => ({
      ...image,
      dialogAlt: imageIndex === index ? alt : `${baseTitle} image ${imageIndex + 1}`,
      dialogTitle: gallery.length > 1 ? `${baseTitle} image ${imageIndex + 1} of ${gallery.length}` : title
    }));
    state.dialogImageIndex = index;
    renderImageDialogReel();
    showDialogImage(index);
    elements.commentImageDialog.showModal();
  }

  function openCommentImage(images, index, alt) {
    openImageDialog(images[index], alt, "Comment image", images, index, "Comment");
  }

  function closeCommentImageDialog() {
    if (elements.commentImageDialog.open) {
      elements.commentImageDialog.close();
    }
  }

  function resetImageDialog() {
    elements.commentImageDialogImage.removeAttribute("src");
    elements.commentImageDialogImage.alt = "";
    elements.commentImageDialogTitle.textContent = "Image preview";
    state.dialogImages = [];
    state.dialogImageIndex = 0;
    elements.imageDialogReelTrack.replaceChildren();
  }

  async function deleteComment(commentId) {
    if (!window.confirm("Delete this comment? This cannot be undone.")) {
      return;
    }

    state.data.products = state.data.products.map((product) => (
      product.id === state.productId
        ? { ...product, comments: (product.comments || []).filter((comment) => comment.id !== commentId) }
        : product
    ));
    await persistAndRender();
  }

  function renderReferences(product) {
    const referenceUrls = product.referenceUrls || [];
    elements.referenceList.replaceChildren();
    elements.references.dataset.available = String(referenceUrls.length > 0);
    elements.emptyReferences.hidden = referenceUrls.length > 0;

    referenceUrls.forEach((url, index) => {
      const item = document.createElement("li");
      const link = document.createElement("a");
      const remove = document.createElement("button");
      link.href = url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.title = url;
      link.textContent = url;
      remove.type = "button";
      remove.className = "remove-reference-url";
      remove.dataset.referenceIndex = String(index);
      remove.setAttribute("aria-label", `Remove reference link ${index + 1}`);
      remove.title = "Remove reference link";
      remove.textContent = "×";
      item.append(link, remove);
      elements.referenceList.append(item);
    });
  }

  function normalizeReferenceUrl(rawUrl) {
    const trimmed = rawUrl.trim();
    const candidate = /^[a-z][a-z\d+.-]*:/i.test(trimmed) ? trimmed : `https://${trimmed}`;
    return Store.normalizeProduct({ referenceUrls: [candidate] }).referenceUrls[0] || "";
  }

  async function addReferenceUrl(event) {
    event.preventDefault();
    const product = getProduct();
    const referenceUrls = [...(product?.referenceUrls || [])];
    const url = normalizeReferenceUrl(elements.referenceInput.value);

    if (!product || !url) {
      elements.referenceStatus.textContent = "Enter a valid http or https link.";
      return;
    }
    if (referenceUrls.includes(url)) {
      elements.referenceStatus.textContent = "This reference link is already added.";
      return;
    }
    if (referenceUrls.length >= 8) {
      elements.referenceStatus.textContent = "A product can have up to 8 reference links.";
      return;
    }

    state.data.products = state.data.products.map((entry) => (
      entry.id === product.id ? { ...entry, referenceUrls: [...referenceUrls, url] } : entry
    ));
    elements.referenceInput.value = "";
    await persistAndRender();
    elements.referenceStatus.textContent = "Reference link added.";
  }

  async function removeReferenceUrl(index) {
    const product = getProduct();
    const referenceUrls = [...(product?.referenceUrls || [])];
    const url = referenceUrls[index];

    if (!product || !url || !window.confirm(`Remove reference link ${url}?`)) return;
    referenceUrls.splice(index, 1);
    state.data.products = state.data.products.map((entry) => (
      entry.id === product.id ? { ...entry, referenceUrls } : entry
    ));
    await persistAndRender();
    elements.referenceStatus.textContent = "Reference link removed.";
  }

  function renderProductRelations(product) {
    const renderRelation = (container, ids) => {
      const products = ids.map((id) => state.data.products.find((entry) => entry.id === id)).filter(Boolean);
      const list = container.querySelector("ul");
      list.replaceChildren();
      list.className = "relation-preview-list";
      container.dataset.available = String(products.length > 0);
      container.querySelector(".resource-empty-state").hidden = products.length > 0;
      products.forEach((related) => {
        const item = document.createElement("li");
        const link = document.createElement("a");
        const media = document.createElement("div");
        const copy = document.createElement("div");
        const title = document.createElement("strong");
        const description = document.createElement("p");
        const metadata = document.createElement("span");
        const price = document.createElement("b");
        const image = related.images?.[0]?.src;

        item.className = "relation-preview-item";
        link.href = Store.getExtensionUrl(`product.html?id=${encodeURIComponent(related.id)}`);
        link.className = "relation-product-preview";
        media.className = "relation-preview-image";
        if (image && state.data.settings.showImages) {
          const thumbnail = document.createElement("img");
          thumbnail.src = image;
          thumbnail.alt = "";
          media.append(thumbnail);
        } else {
          media.textContent = "Product";
        }
        copy.className = "relation-preview-copy";
        title.textContent = related.title;
        description.textContent = related.description || "No product details added.";
        metadata.textContent = `${Store.getCategoryLabel(state.data, related.department)} · ${Store.formatMoq(related.moq)}`;
        price.textContent = `Total ${Store.formatMoney(related.price, state.data.settings)} · ${related.inStock ? "In stock" : "Out of stock"}`;
        copy.append(title, description, metadata, price);
        link.append(media, copy);
        item.append(link);
        list.append(item);
      });
    };
    renderRelation(elements.relatedProducts, product.relatedProductIds || []);
    renderRelation(elements.bundleProducts, product.bundleProductIds || []);
    renderResourceTabs();
  }

  function renderProductVendors(product) {
    const vendors = state.data.vendors
      .filter((vendor) => vendor.productIds.includes(product.id))
      .sort((first, second) => first.name.localeCompare(second.name));
    const list = elements.vendorsPanel.querySelector("ul");
    list.replaceChildren();
    list.className = "vendor-preview-list";
    elements.vendorsPanel.dataset.available = String(vendors.length > 0);
    elements.vendorsPanel.querySelector(".resource-empty-state").hidden = vendors.length > 0;

    vendors.forEach((vendor) => {
      const item = document.createElement("li");
      const card = document.createElement("a");
      const title = document.createElement("strong");
      const type = document.createElement("span");
      const contact = document.createElement("span");
      const spocs = document.createElement("span");
      const directContact = [vendor.phone, vendor.email].filter(Boolean).join(" · ");

      item.className = "vendor-preview-item";
      card.className = "vendor-product-preview";
      card.href = Store.getExtensionUrl("vendors.html");
      title.textContent = vendor.name;
      type.textContent = vendorTypeLabel(vendor.type);
      contact.textContent = directContact || vendor.address || vendor.website || "No contact details added";
      spocs.textContent = vendor.contacts.length
        ? `${vendor.contacts.length} ${vendor.contacts.length === 1 ? "SPOC" : "SPOCs"} linked`
        : "No SPOCs linked";
      card.append(title, type, contact, spocs);
      item.append(card);
      list.append(item);
    });

    renderResourceTabs();
  }

  function setResourceTab(tabName) {
    state.activeResourceTab = tabName;
    renderResourceTabs();
  }

  function renderResourceTabs() {
    const persistentTabs = new Set(["description", "references", "related", "vendors", "comments"]);
    elements.descriptionPanel.dataset.available = "true";
    elements.references.dataset.available = "true";
    elements.relatedProducts.dataset.available = "true";
    elements.vendorsPanel.dataset.available = "true";
    elements.commentsPanel.dataset.available = "true";
    const panels = [...elements.resourceTabs.querySelectorAll("[data-resource-panel]")];
    const availablePanels = panels.filter((panel) => (
      persistentTabs.has(panel.dataset.resourcePanel) || panel.dataset.available !== "false"
    ));
    elements.resourceTabs.hidden = availablePanels.length === 0;

    if (!availablePanels.length) {
      return;
    }

    const selectedPanel = availablePanels.find((panel) => panel.dataset.resourcePanel === state.activeResourceTab)
      || availablePanels[0];
    state.activeResourceTab = selectedPanel.dataset.resourcePanel;
    panels.forEach((panel) => {
      panel.hidden = panel !== selectedPanel;
    });
    elements.resourceTabButtons.forEach((button) => {
      const selected = button.dataset.resourceTab === state.activeResourceTab;
      const hasPanel = availablePanels.some((panel) => panel.dataset.resourcePanel === button.dataset.resourceTab);
      button.hidden = !hasPanel;
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
    });
  }

  function renderMissing() {
    elements.productDetail.hidden = true;
    elements.missingProduct.hidden = false;
  }

  function render() {
    const product = getProduct();

    renderSettings();

    if (!product) {
      renderMissing();
      return;
    }

    const activeCart = getActiveCart();
    const activeItem = getActiveItem();
    const cartCount = activeCart.items.length;

    document.title = `${product.title} - ToDoList Cart`;
    elements.productDetail.hidden = false;
    elements.missingProduct.hidden = true;
    renderCategoryNav(product);
    renderProductImage(product);
    renderCartSelector();

    elements.title.textContent = product.title;
    elements.stars.textContent = Store.getStars(product.priority);
    elements.priority.textContent = Store.getPriorityLabel(product.priority);
    elements.rating.dataset.priority = elements.priority.textContent;
    elements.rating.setAttribute("aria-label", `Priority: ${elements.priority.textContent}`);
    elements.rating.tabIndex = 0;
    Store.renderCategory(elements.department, state.data, product.department);
    elements.productType.textContent = product.productType;
    elements.location.textContent = product.location;
    elements.moq.textContent = Store.formatMoq(product.moq);
    const unitsInStock = Store.getUnitsInStock(product);
    elements.stockUnits.textContent = `${unitsInStock} ${unitsInStock === 1 ? "unit" : "units"}`;
    elements.unitPrice.textContent = Store.formatMoney(product.unitPrice, state.data.settings);
    elements.price.textContent = Store.formatMoney(product.price, state.data.settings);
    elements.created.textContent = Store.formatDate(product.createdAt);
    elements.description.textContent = product.description || "No description added yet.";
    renderReferences(product);
    renderProductRelations(product);
    renderProductVendors(product);
    renderComments(product);
    elements.cartCount.textContent = cartCount;
    elements.cartStatus.textContent = activeItem
      ? `In ${activeCart.name}${activeItem.done ? " and checked out" : ""}`
      : `Not in ${activeCart.name}`;
    elements.stockStatus.hidden = product.inStock;
    elements.addCart.disabled = Boolean(activeItem) || !product.inStock;
    elements.buyNow.disabled = !product.inStock;
    elements.removeCart.disabled = !activeItem;
    elements.done.disabled = !activeItem;
    elements.done.checked = Boolean(activeItem?.done);
  }

  function renderSettings() {
    elements.brandName.textContent = state.data.settings.storeName;
    document.body.classList.toggle("compact-mode", state.data.settings.compactMode);
  }

  async function persistAndRender() {
    state.data = await Store.saveData(state.data);
    render();
  }

  async function addComment(event) {
    event.preventDefault();
    const text = elements.commentText.value.trim();
    const title = elements.commentTitle.value.trim();

    if (!title && !text && !state.commentImages.length) {
      return;
    }

    state.data.products = state.data.products.map((product) => (
      product.id === state.productId
        ? {
          ...product,
          comments: [...(product.comments || []), {
            id: Store.createId("comment"),
            title,
            text,
            images: state.commentImages,
            createdAt: Date.now()
          }]
        }
        : product
    ));
    elements.commentForm.reset();
    state.commentImages = [];
    renderCommentImagePreview();
    await persistAndRender();
  }

  function renderCommentImagePreview() {
    elements.commentImagePreview.replaceChildren();
    elements.commentImagePreview.hidden = state.commentImages.length === 0;
    state.commentImages.forEach((entry, index) => {
      const image = document.createElement("img");
      image.src = entry.src;
      image.alt = entry.name || `Comment image ${index + 1}`;
      elements.commentImagePreview.append(image);
    });
  }

  async function addCommentImages(files) {
    const remaining = Math.max(0, 4 - state.commentImages.length);
    const selected = [...files]
      .filter((file) => file.type.startsWith("image/"))
      .slice(0, remaining);
    const images = [...state.commentImages];

    for (const file of selected) {
      if (file.size <= MAX_COMMENT_IMAGE_BYTES) {
        images.push({
          src: await Store.fileToDataUrl(file),
          name: file.name || "clipboard-image"
        });
      } else {
        alert("Choose comment images up to 5 MB.");
      }
    }

    state.commentImages = images;
    renderCommentImagePreview();
  }

  async function addToCart() {
    const activeCart = getActiveCart();

    if (getActiveItem() || !getProduct()?.inStock) {
      return;
    }

    setActiveCart({
      ...activeCart,
      items: [{
        id: Store.createId("item"),
        productId: state.productId,
        done: false,
        addedAt: Date.now()
      }, ...activeCart.items]
    });

    await persistAndRender();
  }

  async function buyNow() {
    const product = getProduct();

    if (!product?.inStock) {
      return;
    }

    window.location.href = Store.getExtensionUrl(`buy-now.html?id=${encodeURIComponent(state.productId)}`);
  }

  async function removeFromCart() {
    const activeCart = getActiveCart();
    setActiveCart({
      ...activeCart,
      items: activeCart.items.filter((item) => item.productId !== state.productId)
    });
    await persistAndRender();
  }

  async function toggleDone(done) {
    const activeCart = getActiveCart();
    const item = getActiveItem();

    if (!item || item.done === done) {
      return;
    }

    setActiveCart({
      ...activeCart,
      items: activeCart.items.map((item) => (
        item.productId === state.productId ? { ...item, done } : item
      ))
    });
    state.data.products = state.data.products.map((product) => {
      if (product.id !== state.productId) {
        return product;
      }

      const completedUnits = Math.max(0, Number(product.completedUnits || 0) + (done ? 1 : -1));
      return {
        ...product,
        completedUnits,
        inStock: done && completedUnits >= Number(product.availableUnits) ? false : product.inStock
      };
    });
    await persistAndRender();
  }

  async function deleteProduct() {
    state.data.products = state.data.products.filter((product) => product.id !== state.productId);
    state.data.wishlist = state.data.wishlist.filter((productId) => productId !== state.productId);
    state.data.carts = state.data.carts.map((cart) => ({
      ...cart,
      items: cart.items.filter((item) => item.productId !== state.productId)
    }));
    await Store.saveData(state.data);
    window.location.href = Store.getExtensionUrl("products.html");
  }

  function editProduct() {
    window.location.href = Store.getExtensionUrl(`create-product.html?id=${encodeURIComponent(state.productId)}`);
  }

  async function duplicateProduct() {
    const product = getProduct();

    if (!product) {
      return;
    }

    elements.duplicateProduct.disabled = true;

    try {
      const copy = Store.createProduct({
        title: `${product.title} (Copy)`,
        department: product.department,
        productType: product.productType,
        location: product.location,
        priority: product.priority,
        moq: product.moq,
        unitPrice: product.unitPrice,
        price: product.price,
        inStock: product.inStock,
        availableUnits: product.availableUnits,
        completedUnits: product.completedUnits,
        description: product.description,
        referenceUrls: [...(product.referenceUrls || [])],
        relatedProductIds: [...(product.relatedProductIds || [])],
        bundleProductIds: [...(product.bundleProductIds || [])],
        images: (product.images || []).map((image) => ({ ...image }))
      });

      state.data.products.unshift(copy);
      state.data = await Store.saveData(state.data);
      window.location.href = Store.getExtensionUrl(`create-product.html?id=${encodeURIComponent(copy.id)}`);
    } catch (error) {
      console.error("Could not duplicate product", error);
      elements.duplicateProduct.disabled = false;
      window.alert("The product could not be duplicated. Please try again.");
    }
  }

  function bindEvents() {
    elements.cartSelect.addEventListener("change", async () => {
      state.data.activeCartId = elements.cartSelect.value;
      await persistAndRender();
    });

    elements.addCart.addEventListener("click", addToCart);
    elements.buyNow.addEventListener("click", buyNow);
    elements.removeCart.addEventListener("click", removeFromCart);
    elements.done.addEventListener("change", () => toggleDone(elements.done.checked));
    elements.commentPanelToggle.addEventListener("click", toggleCommentPanelPlacement);
    elements.departments.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-department]");

      if (button) {
        openCategory(button.dataset.department);
      }
    });
    elements.resourceTabButtons.forEach((button) => {
      button.addEventListener("click", () => setResourceTab(button.dataset.resourceTab));
    });
    elements.referenceForm.addEventListener("submit", addReferenceUrl);
    elements.referenceList.addEventListener("click", (event) => {
      const remove = event.target.closest(".remove-reference-url");
      if (remove) removeReferenceUrl(Number(remove.dataset.referenceIndex));
    });
    elements.closeCommentImageDialog.addEventListener("click", closeCommentImageDialog);
    elements.commentImageDialog.addEventListener("click", (event) => {
      if (event.target === elements.commentImageDialog) {
        closeCommentImageDialog();
      }
    });
    elements.commentImageDialog.addEventListener("close", resetImageDialog);
    elements.imageDialogReelPrevious.addEventListener("click", () => {
      elements.imageDialogReelTrack.scrollBy({ left: -240, behavior: "smooth" });
    });
    elements.imageDialogReelNext.addEventListener("click", () => {
      elements.imageDialogReelTrack.scrollBy({ left: 240, behavior: "smooth" });
    });
    elements.commentForm.addEventListener("submit", addComment);
    elements.commentImageInput.addEventListener("change", () => addCommentImages(elements.commentImageInput.files || []));
    elements.commentForm.addEventListener("paste", (event) => {
      const files = [...(event.clipboardData?.files || [])]
        .filter((file) => file.type.startsWith("image/"));

      if (files.length) {
        event.preventDefault();
        addCommentImages(files);
      }
    });
    elements.editProduct.addEventListener("click", editProduct);
    elements.duplicateProduct.addEventListener("click", duplicateProduct);
    elements.deleteProduct.addEventListener("click", deleteProduct);

    elements.openProductsPage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("products.html");
    });

    elements.openHomePage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("newtab.html");
    });

    elements.openOrdersPage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("order-history.html");
    });

    elements.openAccountPage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("account.html");
    });

    elements.missingProductsLink.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("products.html");
    });
  }

  async function init() {
    bindEvents();
    state.data = await Store.loadData();
    render();
    applyCommentPanelPlacement();
  }

  init();
})();
