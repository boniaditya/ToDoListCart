(function () {
  const Store = globalThis.ToDoCartStore;
  const SORT_OPTIONS = new Set([
    "default",
    "price-asc",
    "price-desc",
    "time-asc",
    "time-desc",
    "comments-asc",
    "comments-desc"
  ]);
  const savedSort = localStorage.getItem("todoListCart.productSort");
  const searchParams = new URLSearchParams(window.location.search);
  const state = {
    data: Store.normalizeData({}),
    department: searchParams.get("department") || "all",
    query: "",
    wishlistOnly: searchParams.get("view") === "wishlist",
    viewMode: localStorage.getItem("todoListCart.productView") === "list" ? "list" : "card",
    sortMode: SORT_OPTIONS.has(savedSort) ? savedSort : "default"
  };

  const elements = {
    brandName: document.querySelector(".brand-name"),
    searchForm: document.querySelector("#search-form"),
    searchInput: document.querySelector("#search-products"),
    departments: document.querySelector(".departments"),
    productList: document.querySelector("#product-list"),
    listingTitle: document.querySelector("#listing-title"),
    sortSelect: document.querySelector("#product-sort"),
    viewButtons: document.querySelectorAll(".view-toggle-button"),
    productTemplate: document.querySelector("#product-template"),
    emptyProducts: document.querySelector("#empty-products"),
    productCount: document.querySelector("#product-count"),
    visibleCount: document.querySelector("#visible-count"),
    cartCount: document.querySelector("#cart-count"),
    cartSummary: document.querySelector("#cart-summary"),
    cartSelect: document.querySelector("#cart-select"),
    openHomePage: document.querySelector("#open-home-page"),
    openOrdersPage: document.querySelector("#open-orders-page"),
    openAccountPage: document.querySelector("#open-account-page"),
    cartJump: document.querySelector("#cart-jump")
  };

  function getActiveCart() {
    return Store.getActiveCart(state.data);
  }

  function getActiveItems() {
    return getActiveCart().items;
  }

  function cartHasProduct(productId) {
    return getActiveItems().some((item) => item.productId === productId);
  }

  function getCategoryName(product) {
    return Store.getCategoryLabel(state.data, product.department);
  }

  function getVisibleProducts() {
    const query = state.query.toLowerCase();

    const visibleProducts = state.data.products.filter((product) => {
      const categoryName = getCategoryName(product);
      const matchesDepartment = state.department === "all" || product.department === state.department;
      const matchesQuery = !query || [
        product.title,
        categoryName,
        product.priority,
        product.location,
        product.description,
        product.moq,
        product.price
      ].some((value) => String(value).toLowerCase().includes(query));

      const matchesWishlist = !state.wishlistOnly || state.data.wishlist.includes(product.id);

      return matchesDepartment && matchesQuery && matchesWishlist;
    });

    if (state.sortMode === "default") {
      return visibleProducts;
    }

    const direction = state.sortMode.endsWith("-desc") ? -1 : 1;
    const sortKey = state.sortMode.replace(/-(asc|desc)$/, "");
    const timeRate = Number(state.data.settings.timeRate) / Number(state.data.settings.timeSeconds || 1);
    const getSortValue = (product) => {
      if (sortKey === "comments") {
        return product.comments.length;
      }

      if (sortKey === "time") {
        return timeRate > 0 ? Number(product.price || 0) / timeRate : Number(product.price || 0);
      }

      return Number(product.price || 0);
    };

    return visibleProducts.sort((first, second) => {
      const difference = (getSortValue(first) - getSortValue(second)) * direction;
      return difference || first.title.localeCompare(second.title);
    });
  }

  function pluralize(count, singular, plural) {
    return `${count} ${count === 1 ? singular : plural}`;
  }

  function createWishlistIcon() {
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");

    icon.classList.add("wishlist-icon");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("aria-hidden", "true");
    icon.setAttribute("focusable", "false");
    path.setAttribute("d", "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78Z");
    icon.append(path);
    return icon;
  }

  function fitCardImage(image) {
    const fit = () => {
      const frame = image.closest(".product-carousel-slide") || image.closest(".product-image");

      if (!frame?.clientWidth || !frame.clientHeight || !image.naturalWidth || !image.naturalHeight) {
        return;
      }

      const imageRatio = image.naturalWidth / image.naturalHeight;
      const frameRatio = frame.clientWidth / frame.clientHeight;
      const fillWidth = imageRatio >= frameRatio;

      image.style.setProperty("width", fillWidth ? "100%" : "auto", "important");
      image.style.setProperty("height", fillWidth ? "auto" : "100%", "important");
      image.style.setProperty("max-width", "100%", "important");
      image.style.setProperty("max-height", "100%", "important");
    };

    image.addEventListener("load", () => requestAnimationFrame(fit), { once: true });
    if (image.complete) {
      requestAnimationFrame(fit);
    }
  }

  function renderProductImage(container, product, isWishlisted) {
    container.replaceChildren();
    const images = product.images || [];

    if (images.length && state.data.settings.listingShowImages) {
      if (images.length > 1) {
        const track = document.createElement("div");
        const previous = document.createElement("button");
        const next = document.createElement("button");
        const dots = document.createElement("div");

        track.className = "product-carousel-track";
        images.forEach((entry, index) => {
          const slide = document.createElement("div");
          const image = document.createElement("img");

          slide.className = "product-carousel-slide";
          image.src = entry.cardSrc || entry.src;
          image.alt = `${product.title} product image ${index + 1} of ${images.length}`;
          fitCardImage(image);
          slide.append(image);
          track.append(slide);
        });

        previous.type = "button";
        previous.className = "carousel-button previous";
        previous.dataset.carouselDirection = "-1";
        previous.setAttribute("aria-label", `Show previous image for ${product.title}`);
        previous.textContent = "‹";

        next.type = "button";
        next.className = "carousel-button next";
        next.dataset.carouselDirection = "1";
        next.setAttribute("aria-label", `Show next image for ${product.title}`);
        next.textContent = "›";

        dots.className = "carousel-dots";
        images.forEach((_, index) => {
          const dot = document.createElement("button");
          dot.type = "button";
          dot.className = "carousel-dot";
          dot.dataset.carouselIndex = String(index);
          dot.setAttribute("aria-label", `Show image ${index + 1} of ${images.length} for ${product.title}`);
          dot.setAttribute("aria-current", String(index === 0));
          dots.append(dot);
        });

        container.dataset.imageIndex = "0";
        container.append(track, previous, next, dots);
      } else {
        const image = document.createElement("img");
        image.src = images[0].cardSrc || images[0].src;
        image.alt = `${product.title} product image`;
        fitCardImage(image);
        container.append(image);
      }
    } else {
      container.append(document.createElement("span"));
    }

    const wishlistButton = document.createElement("button");
    wishlistButton.type = "button";
    wishlistButton.className = "wishlist-button";
    wishlistButton.setAttribute("aria-label", isWishlisted ? `Remove ${product.title} from wishlist` : `Add ${product.title} to wishlist`);
    wishlistButton.setAttribute("aria-pressed", String(isWishlisted));
    wishlistButton.append(createWishlistIcon());
    container.append(wishlistButton);

  }

  function moveCarousel(button) {
    const card = button.closest(".product-card");
    const product = state.data.products.find((entry) => entry.id === card?.dataset.id);
    const container = button.closest(".product-image");
    const images = product?.images || [];

    if (!container || images.length < 2) {
      return;
    }

    const currentIndex = Number(container.dataset.imageIndex || 0);
    const direction = Number(button.dataset.carouselDirection || 1);
    const nextIndex = (currentIndex + direction + images.length) % images.length;

    setCarouselImage(container, nextIndex);
  }

  function setCarouselImage(container, index) {
    if (!container) {
      return;
    }

    const card = container.closest(".product-card");
    const product = state.data.products.find((entry) => entry.id === card?.dataset.id);
    const images = product?.images || [];

    if (images.length < 2) {
      return;
    }

    container.dataset.imageIndex = String(index);
    container.querySelector(".product-carousel-track").style.transform = `translateX(-${index * 100}%)`;
    container.querySelectorAll(".carousel-dot").forEach((dot, dotIndex) => {
      const isActive = dotIndex === index;
      dot.classList.toggle("active", isActive);
      dot.setAttribute("aria-current", String(isActive));
    });
  }

  function renderCartSelector() {
    elements.cartSelect.replaceChildren();

    state.data.carts.forEach((cart) => {
      const option = document.createElement("option");
      option.value = cart.id;
      option.textContent = cart.name;
      elements.cartSelect.append(option);
    });

    elements.cartSelect.value = state.data.activeCartId;
  }

  function renderCategoryNav() {
    elements.departments.replaceChildren();

    const allButton = document.createElement("button");
    allButton.type = "button";
    allButton.dataset.department = "all";
    allButton.textContent = "All";
    elements.departments.append(allButton);

    state.data.categories.forEach((category) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.department = category.id;
      Store.renderCategory(button, state.data, category.id);
      elements.departments.append(button);
    });

    if (state.department !== "all" && !state.data.categories.some((category) => category.id === state.department)) {
      state.department = "all";
    }

    elements.departments.querySelectorAll("button").forEach((button) => {
      const active = button.dataset.department === state.department;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });
  }

  function renderSummary() {
    const activeCart = getActiveCart();
    const productsById = new Map(state.data.products.map((product) => [product.id, product]));
    const cartProducts = activeCart.items
      .map((item) => ({ item, product: productsById.get(item.productId) }))
      .filter((entry) => entry.product);
    const cartCount = cartProducts.length;
    const open = cartProducts.filter((entry) => !entry.item.done).length;
    const total = Store.getTotalAmount(cartProducts.map((entry) => entry.product));

    const displayedCount = state.wishlistOnly ? state.data.wishlist.length : state.data.products.length;
    elements.productCount.textContent = state.wishlistOnly
      ? `${displayedCount} saved`
      : pluralize(displayedCount, "product", "products");
    elements.visibleCount.textContent = `${getVisibleProducts().length} shown`;
    elements.cartCount.textContent = cartCount;
    elements.cartSummary.textContent = `${activeCart.name}: ${open} open | ${Store.formatMoney(total, state.data.settings)}`;
  }

  function renderProducts() {
    const visibleProducts = getVisibleProducts();
    elements.productList.replaceChildren();

    visibleProducts.forEach((product) => {
      const node = elements.productTemplate.content.firstElementChild.cloneNode(true);
      const imageBox = node.querySelector(".product-image");
      const title = node.querySelector(".product-title");
      const description = node.querySelector(".product-description");
      const stars = node.querySelector(".rating-stars");
      const ratingRow = node.querySelector(".rating-row");
      const priority = node.querySelector(".priority-label");
      const department = node.querySelector(".department-label");
      const location = node.querySelector(".location-label");
      const locationValue = node.querySelector(".location-value");
      const moq = node.querySelector(".moq-label");
      const units = node.querySelector(".units-label");
      const price = node.querySelector(".price-label");
      const time = node.querySelector(".time-label");
      const timeValue = node.querySelector(".time-value");
      const commentButton = node.querySelector(".comment-count-button");
      const commentCount = node.querySelector(".comment-count-value");
      const stockStatus = node.querySelector(".stock-status");
      const addButton = node.querySelector(".add-cart-button");
      const buyNowButton = node.querySelector(".buy-now-button");

      node.dataset.id = product.id;
      node.classList.toggle("out-of-stock", !product.inStock);
      node.tabIndex = 0;
      node.setAttribute("role", "link");
      node.setAttribute("aria-label", `View details for ${product.title}`);
      const isWishlisted = state.data.wishlist.includes(product.id);
      renderProductImage(imageBox, product, isWishlisted);
      title.textContent = product.title;
      description.textContent = product.description || "No additional details provided.";
      stars.textContent = Store.getStars(product.priority);
      ratingRow.hidden = !state.data.settings.listingShowRatings;
      priority.textContent = Store.getPriorityLabel(product.priority);
      ratingRow.dataset.priority = priority.textContent;
      ratingRow.setAttribute("aria-label", `Priority: ${priority.textContent}`);
      ratingRow.tabIndex = 0;
      Store.renderCategory(department, state.data, product.department);
      department.hidden = !state.data.settings.listingShowCategory;
      department.dataset.department = product.department;
      department.setAttribute("aria-label", "Show " + Store.getCategoryLabel(state.data, product.department) + " products");
      locationValue.textContent = product.location;
      location.hidden = !state.data.settings.listingShowLocation;
      location.dataset.location = product.location;
      location.setAttribute("aria-label", "Show products in " + product.location);
      location.querySelector(".location-card-icon").hidden = !state.data.settings.listingShowLocationIcon;
      moq.textContent = Store.formatMoq(product.moq);
      moq.hidden = !state.data.settings.listingShowMoq;
      const unitsInStock = Store.getUnitsInStock(product);
      units.textContent = `${unitsInStock} ${unitsInStock === 1 ? "unit" : "units"}`;
      units.hidden = !state.data.settings.listingShowUnits;
      const [money, duration] = Store.formatMoney(product.price, state.data.settings).split(" · ");
      price.textContent = `Total ${money}`;
      price.hidden = !state.data.settings.listingShowPrice;
      time.hidden = !duration || !state.data.settings.listingShowTime;
      timeValue.textContent = duration || "";
      time.querySelector(".time-card-icon").hidden = !state.data.settings.listingShowTimeIcon;
      commentCount.textContent = String(product.comments.length);
      commentButton.setAttribute("aria-label", `Open ${product.comments.length} ${product.comments.length === 1 ? "comment" : "comments"} for ${product.title}`);
      commentButton.title = `${product.comments.length} ${product.comments.length === 1 ? "comment" : "comments"}`;
      if (stockStatus) {
        stockStatus.hidden = product.inStock;
      }

      if (!product.inStock) {
        addButton.textContent = "Out of stock";
        addButton.disabled = true;
        addButton.classList.add("out-of-stock");
        buyNowButton.disabled = true;
      } else if (cartHasProduct(product.id)) {
        addButton.textContent = "In Cart";
        addButton.classList.add("in-cart");
        addButton.disabled = true;
      }

      elements.productList.append(node);
    });

    elements.emptyProducts.hidden = visibleProducts.length > 0;
  }

  function render() {
    elements.listingTitle.textContent = state.wishlistOnly ? "My wishlist" : "All todo products";
    elements.sortSelect.value = state.sortMode;
    renderCategoryNav();
    renderSettings();
    renderCartSelector();
    renderProducts();
    renderSummary();
    renderViewMode();
  }

  function renderViewMode() {
    elements.productList.classList.toggle("list-view", state.viewMode === "list");
    elements.productList.classList.toggle("card-view", state.viewMode === "card");
    elements.viewButtons.forEach((button) => {
      const active = button.dataset.view === state.viewMode;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });
  }

  function setViewMode(viewMode) {
    state.viewMode = viewMode === "list" ? "list" : "card";
    localStorage.setItem("todoListCart.productView", state.viewMode);
    renderViewMode();
  }

  function renderSettings() {
    elements.brandName.textContent = state.data.settings.storeName;
    document.body.classList.toggle("compact-mode", state.data.settings.listingCompactMode);
    document.body.classList.toggle("hide-product-descriptions", !state.data.settings.listingShowProductDescriptions);
    document.body.classList.toggle("hide-delivery-status", !state.data.settings.listingShowDeliveryStatus);
  }

  async function persistAndRender() {
    state.data = await Store.saveData(state.data);
    render();
  }

  async function addToCart(productId) {
    const activeCart = getActiveCart();

    const product = state.data.products.find((entry) => entry.id === productId);

    if (activeCart.items.some((item) => item.productId === productId) || !product?.inStock) {
      return;
    }

    state.data.carts = state.data.carts.map((cart) => (
      cart.id === activeCart.id
        ? {
            ...cart,
            items: [{
              id: Store.createId("item"),
              productId,
              done: false,
              addedAt: Date.now()
            }, ...cart.items]
          }
        : cart
    ));

    await persistAndRender();
  }

  async function buyNow(productId) {
    const product = state.data.products.find((entry) => entry.id === productId);

    if (!product?.inStock) {
      return;
    }

    window.location.href = Store.getExtensionUrl(`buy-now.html?id=${encodeURIComponent(productId)}`);
  }

  async function toggleWishlist(productId) {
    state.data.wishlist = state.data.wishlist.includes(productId)
      ? state.data.wishlist.filter((id) => id !== productId)
      : [...state.data.wishlist, productId];
    await persistAndRender();
  }

  function openProductDetail(productId, tabName = "") {
    const tabQuery = tabName ? `&tab=${encodeURIComponent(tabName)}` : "";
    window.location.href = Store.getExtensionUrl(`product.html?id=${encodeURIComponent(productId)}${tabQuery}`);
  }

  function setDepartment(department) {
    state.department = department;
    renderCategoryNav();
    renderProducts();
    renderSummary();
  }

  function bindEvents() {
    elements.searchForm.addEventListener("submit", (event) => {
      event.preventDefault();
      state.query = elements.searchInput.value.trim();
      renderProducts();
      renderSummary();
    });

    elements.searchInput.addEventListener("input", () => {
      state.query = elements.searchInput.value.trim();
      renderProducts();
      renderSummary();
    });

    elements.departments.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-department]");

      if (button) {
        setDepartment(button.dataset.department);
      }
    });

    elements.viewButtons.forEach((button) => {
      button.addEventListener("click", () => setViewMode(button.dataset.view));
    });

    elements.sortSelect.addEventListener("change", () => {
      state.sortMode = SORT_OPTIONS.has(elements.sortSelect.value) ? elements.sortSelect.value : "default";
      localStorage.setItem("todoListCart.productSort", state.sortMode);
      renderProducts();
    });

    elements.cartSelect.addEventListener("change", async () => {
      state.data.activeCartId = elements.cartSelect.value;
      await persistAndRender();
    });

    elements.productList.addEventListener("click", (event) => {
      const filterButton = event.target.closest("[data-card-filter]");
      const carouselButton = event.target.closest(".carousel-button");
      const carouselDot = event.target.closest(".carousel-dot");
      const wishlistButton = event.target.closest(".wishlist-button");
      const commentButton = event.target.closest(".comment-count-button");
      const addButton = event.target.closest(".add-cart-button");
      const buyNowButton = event.target.closest(".buy-now-button");

      if (filterButton) {
        if (filterButton.dataset.cardFilter === "category") {
          setDepartment(filterButton.dataset.department);
        } else {
          state.query = filterButton.dataset.location || "";
          elements.searchInput.value = state.query;
          renderProducts();
          renderSummary();
        }
        return;
      }

      if (carouselButton) {
        moveCarousel(carouselButton);
        return;
      }

      if (carouselDot) {
        setCarouselImage(carouselDot.closest(".product-image"), Number(carouselDot.dataset.carouselIndex));
        return;
      }

      if (wishlistButton) {
        toggleWishlist(wishlistButton.closest(".product-card").dataset.id);
        return;
      }

      if (commentButton) {
        openProductDetail(commentButton.closest(".product-card").dataset.id, "comments");
        return;
      }

      if (addButton) {
        addToCart(addButton.closest(".product-card").dataset.id);
        return;
      }

      if (buyNowButton) {
        buyNow(buyNowButton.closest(".product-card").dataset.id);
        return;
      }

      const card = event.target.closest(".product-card");

      if (card) {
        openProductDetail(card.dataset.id);
      }
    });

    elements.productList.addEventListener("keydown", (event) => {
      const card = event.target.closest(".product-card");

      if (card && event.target === card && (event.key === "Enter" || event.key === " ")) {
        event.preventDefault();
        openProductDetail(card.dataset.id);
      }
    });

    elements.openHomePage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("newtab.html");
    });

    elements.openOrdersPage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("order-history.html");
    });

    elements.openAccountPage.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("account.html");
    });

    elements.cartJump.addEventListener("click", () => {
      window.location.href = Store.getExtensionUrl("cart.html");
    });
  }

  async function init() {
    bindEvents();
    state.data = await Store.loadData();
    const preparedProducts = await Promise.all(state.data.products.map(async (product) => {
      const images = await Store.prepareCardImages(product.images || []);
      return {
        ...product,
        images,
        image: images[0]?.src || "",
        imageName: images[0]?.name || ""
      };
    }));
    if (preparedProducts.some((product, index) => product.images.some((image, imageIndex) => image.cardSrc !== state.data.products[index].images[imageIndex]?.cardSrc))) {
      state.data.products = preparedProducts;
      state.data = await Store.saveData(state.data);
    }
    chrome.storage?.onChanged?.addListener(async (_changes, areaName) => {
      if (areaName !== "local") {
        return;
      }
      state.data = await Store.loadData();
      render();
    });
    render();
  }

  init();
})();
